/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main{
	public static void main(String[] args) {
	 
	 int n =5; 
	   
	 int row =1;   
	 int nsp =n-1; 
	 int nst =1; 
	  
	  while(row <= n) 
	  { 
	   int csp =1; 
	   while(csp<=nsp) 
	   { 
	   System.out.print(" ");
	    csp +=1; 
	   } 
	   
	   int cst =1; 
	   while(cst <= nst)
	   {
	  System.out.print("*");     
	   cst +=1; 
	   }
	   
	   nsp -=1; 
	   nst +=2; 
	   row +=1;
	   
	   System.out.println();
	}
	
	}
}
